 <!-- /.navbar-top-links -->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="\"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="news"><i class="fa fa-table fa-fw"></i> Nuevos</a>
                        </li>
                        <li>
                            <a href="approved"><i class="fa fa-table fa-fw"></i> Aprobados</a>
                        </li>
                        <li>
                            <a href="denied"><i class="fa fa-table fa-fw"></i> Denegados</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-wrench fa-fw"></i>Usuarios<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="/admins">Admin. Usuarios</a>
                                </li>
                                <li>
                                    <a href="#">Reiniciar Clave</a>
                                </li>
                                <li>
                                    <a href="#">Asignar País</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>